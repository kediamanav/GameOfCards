//App42 Android SDK
1. UnZip the downloaded file
2. This will contain app42_android-X.X.X.jar ,doc, sample folder and README.txt
3. doc folder contains JAVA docs
4. Sample folder contains eclipse sample project for using App42 Android SDK.
5. You need to put app42_android-X.X.X.jar in classpath of Android Project to use this.
6. Please visit http://api.shephertz.com/cloudapidocs/index.php for detail documentaion.