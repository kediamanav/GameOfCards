* [Release Version 2.0.1](https://github.com/shephertz/App42_ANDROID_SDK/blob/1.x/Change%20Log.md#version-201)
* [Release Version 2.0](https://github.com/shephertz/App42_ANDROID_SDK/blob/1.x/Change%20Log.md#version-20)
* [Release Version 1.6.1](https://github.com/shephertz/App42_ANDROID_SDK/blob/1.x/Change%20Log.md#version-161)
* [Release Version 1.6](https://github.com/shephertz/App42_ANDROID_SDK/blob/1.x/Change%20Log.md#version-16)

## Version 2.0.1

**Release Date:** 24-12-2013

**Release Version:** 2.0.1

**The following features have been pushed :**

```
None
```

**The following features have been pushed to the services :**

```
None
```
**This release contains the following bug fix:**

```
Crash report bug fix.
```

## Version 2.0

**Release Date:** 12-12-2013

**Release Version:** 2.0

**The following features have been pushed :**

```
Caching and Offline Storage .
```

**The following features have been pushed to the services :**

**SCOREBOARD SERVICE**

```
getTopNRankersFromFacebook (With date range)
```

**This release contains the following bug fix:**

```
None
```


## Version 1.6.1

**Release Date:** 7-08-2013

**Release Version:** 1.6.1

**The following feature have been pushed to the latest :**

```
None
```

**This release contains the following bug fix:**

```
deleteDocumentByKeyValue
```

## Version 1.6

**Release Date:** 05-08-2013

**Release Version:** 1.6

**The following feature have been pushed to the latest :**



**PUSHNOTIFICATION SERVICE**
```
unsubscribeDeviceToChannel
```

**UPLOAD SERVICE**

```
UploadFileForFriend
UploadFileForFriends
UploadFileForGroup
````


**BUDDY SERVICE**

```
sendMessageToGroup
sendMessageToFriend
sendMessageToFriends
getAllMessages
getAllMessagesFromBuddy
getAllMessagesFromGroup
```

**This release contains the following bug fix:**

```
None
```

**Note** : If you wan't to download [1.6 repo] (https://github.com/shephertz/App42_ANDROID_SDK/raw/1.x/1.6/app42_android_1.6.zip) click here.
