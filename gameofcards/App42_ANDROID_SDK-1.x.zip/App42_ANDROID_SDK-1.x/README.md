App42_ANDROID_SDK
=================

App42 Cloud API Client SDK files for Android

[Download the latest App42 Android SDK] (https://github.com/shephertz/App42_ANDROID_SDK/raw/1.x/1.6.1/app42_android_1.6.1.zip)

[Documentation and API guide] (http://api.shephertz.com/app42-dev/android-backend-apis.php)
